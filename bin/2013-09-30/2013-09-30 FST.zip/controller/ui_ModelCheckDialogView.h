/********************************************************************************
** Form generated from reading UI file 'ModelCheckDialogView.ui'
**
** Created: Wed Aug 21 09:24:23 2013
**      by: Qt User Interface Compiler version 4.8.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MODELCHECKDIALOGVIEW_H
#define UI_MODELCHECKDIALOGVIEW_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QFormLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QRadioButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ModelCheckDialogController
{
public:
    QDialogButtonBox *buttonBox;
    QWidget *formLayoutWidget;
    QFormLayout *formLayout;
    QLabel *labelModelFile;
    QLabel *labelPathToFile;
    QLineEdit *lineEditFormula;
    QComboBox *comboFormula;
    QLabel *labelTTC;
    QLineEdit *lineEditTTC;
    QLabel *labelMaxTime;
    QLineEdit *lineEditMaxTime;
    QRadioButton *radioTextInput;
    QLabel *labelFormula;
    QRadioButton *radioDemoInput;

    void setupUi(QDialog *ModelCheckDialogController)
    {
        if (ModelCheckDialogController->objectName().isEmpty())
            ModelCheckDialogController->setObjectName(QString::fromUtf8("ModelCheckDialogController"));
        ModelCheckDialogController->resize(400, 300);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/resources/resources/introduction1.png"), QSize(), QIcon::Normal, QIcon::Off);
        ModelCheckDialogController->setWindowIcon(icon);
        ModelCheckDialogController->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        buttonBox = new QDialogButtonBox(ModelCheckDialogController);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(30, 240, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        formLayoutWidget = new QWidget(ModelCheckDialogController);
        formLayoutWidget->setObjectName(QString::fromUtf8("formLayoutWidget"));
        formLayoutWidget->setGeometry(QRect(10, 10, 381, 221));
        formLayout = new QFormLayout(formLayoutWidget);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        formLayout->setContentsMargins(0, 0, 0, 0);
        labelModelFile = new QLabel(formLayoutWidget);
        labelModelFile->setObjectName(QString::fromUtf8("labelModelFile"));

        formLayout->setWidget(1, QFormLayout::LabelRole, labelModelFile);

        labelPathToFile = new QLabel(formLayoutWidget);
        labelPathToFile->setObjectName(QString::fromUtf8("labelPathToFile"));

        formLayout->setWidget(1, QFormLayout::FieldRole, labelPathToFile);

        lineEditFormula = new QLineEdit(formLayoutWidget);
        lineEditFormula->setObjectName(QString::fromUtf8("lineEditFormula"));
        lineEditFormula->setEnabled(true);

        formLayout->setWidget(3, QFormLayout::FieldRole, lineEditFormula);

        comboFormula = new QComboBox(formLayoutWidget);
        comboFormula->setObjectName(QString::fromUtf8("comboFormula"));

        formLayout->setWidget(5, QFormLayout::FieldRole, comboFormula);

        labelTTC = new QLabel(formLayoutWidget);
        labelTTC->setObjectName(QString::fromUtf8("labelTTC"));
        labelTTC->setEnabled(true);

        formLayout->setWidget(6, QFormLayout::LabelRole, labelTTC);

        lineEditTTC = new QLineEdit(formLayoutWidget);
        lineEditTTC->setObjectName(QString::fromUtf8("lineEditTTC"));
        lineEditTTC->setEnabled(true);

        formLayout->setWidget(6, QFormLayout::FieldRole, lineEditTTC);

        labelMaxTime = new QLabel(formLayoutWidget);
        labelMaxTime->setObjectName(QString::fromUtf8("labelMaxTime"));
        labelMaxTime->setEnabled(true);

        formLayout->setWidget(7, QFormLayout::LabelRole, labelMaxTime);

        lineEditMaxTime = new QLineEdit(formLayoutWidget);
        lineEditMaxTime->setObjectName(QString::fromUtf8("lineEditMaxTime"));
        lineEditMaxTime->setEnabled(true);

        formLayout->setWidget(7, QFormLayout::FieldRole, lineEditMaxTime);

        radioTextInput = new QRadioButton(formLayoutWidget);
        radioTextInput->setObjectName(QString::fromUtf8("radioTextInput"));
        radioTextInput->setChecked(true);

        formLayout->setWidget(2, QFormLayout::FieldRole, radioTextInput);

        labelFormula = new QLabel(formLayoutWidget);
        labelFormula->setObjectName(QString::fromUtf8("labelFormula"));
        labelFormula->setEnabled(true);

        formLayout->setWidget(2, QFormLayout::LabelRole, labelFormula);

        radioDemoInput = new QRadioButton(formLayoutWidget);
        radioDemoInput->setObjectName(QString::fromUtf8("radioDemoInput"));

        formLayout->setWidget(4, QFormLayout::FieldRole, radioDemoInput);

        QWidget::setTabOrder(radioTextInput, lineEditFormula);
        QWidget::setTabOrder(lineEditFormula, radioDemoInput);
        QWidget::setTabOrder(radioDemoInput, comboFormula);
        QWidget::setTabOrder(comboFormula, lineEditTTC);
        QWidget::setTabOrder(lineEditTTC, lineEditMaxTime);
        QWidget::setTabOrder(lineEditMaxTime, buttonBox);

        retranslateUi(ModelCheckDialogController);
        QObject::connect(buttonBox, SIGNAL(accepted()), ModelCheckDialogController, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), ModelCheckDialogController, SLOT(reject()));
        QObject::connect(lineEditFormula, SIGNAL(textEdited(QString)), radioTextInput, SLOT(click()));
        QObject::connect(comboFormula, SIGNAL(currentIndexChanged(int)), radioDemoInput, SLOT(click()));

        QMetaObject::connectSlotsByName(ModelCheckDialogController);
    } // setupUi

    void retranslateUi(QDialog *ModelCheckDialogController)
    {
        ModelCheckDialogController->setWindowTitle(QApplication::translate("ModelCheckDialogController", "STD Configurations", 0, QApplication::UnicodeUTF8));
        labelModelFile->setText(QApplication::translate("ModelCheckDialogController", "Model File", 0, QApplication::UnicodeUTF8));
        labelPathToFile->setText(QApplication::translate("ModelCheckDialogController", "path_to_and_name_of_file", 0, QApplication::UnicodeUTF8));
        lineEditFormula->setText(QApplication::translate("ModelCheckDialogController", "PR<=0.2(X.reservoir<=5.0)", 0, QApplication::UnicodeUTF8));
        comboFormula->clear();
        comboFormula->insertItems(0, QStringList()
         << QApplication::translate("ModelCheckDialogController", "PR<=0.2 (X.reservoir <= 5.0)", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ModelCheckDialogController", "PR<=0.2 (M.pumpon = 0)", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ModelCheckDialogController", "PR<=0.2 (NEG M.pumpon = 0)", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ModelCheckDialogController", "PR<=0.2 (M.pumpon = 0 AND X.reservoir <= 5.0)", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ModelCheckDialogController", "PR<=0.2 (M.pumpon = 0 U[0,10] X.reservoir <= 5.0)", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ModelCheckDialogController", "PR<=0.2 (M.input1on = 1)", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ModelCheckDialogController", "PR<=0.2 (X.soft1 <= 0.1)", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ModelCheckDialogController", "PR<=0.2 (X.soft1 <= 0.2 AND X.soft1 <= 0.1)", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ModelCheckDialogController", "PR<=0.2 (NEG X.soft1 <= 0.1)", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ModelCheckDialogController", "PR<=0.2 (NEG M.input1on = 1)", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ModelCheckDialogController", "PR<=0.2 (TT)", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ModelCheckDialogController", "PR<=0.2 (M.input1on=1 U[0,10] X.soft1<=0.1)", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ModelCheckDialogController", "PR<=0.2 ((M.input1on=1 AND X.soft1<=0.1) U[0,10] X.stor2<=0.2)", 0, QApplication::UnicodeUTF8)
        );
        labelTTC->setText(QApplication::translate("ModelCheckDialogController", "Time To Check", 0, QApplication::UnicodeUTF8));
        lineEditTTC->setText(QApplication::translate("ModelCheckDialogController", "0", 0, QApplication::UnicodeUTF8));
        labelMaxTime->setText(QApplication::translate("ModelCheckDialogController", "Maximum Time", 0, QApplication::UnicodeUTF8));
        lineEditMaxTime->setText(QApplication::translate("ModelCheckDialogController", "100", 0, QApplication::UnicodeUTF8));
        radioTextInput->setText(QApplication::translate("ModelCheckDialogController", "Textual Input", 0, QApplication::UnicodeUTF8));
        labelFormula->setText(QApplication::translate("ModelCheckDialogController", "Formula", 0, QApplication::UnicodeUTF8));
        radioDemoInput->setText(QApplication::translate("ModelCheckDialogController", "Demo Input", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class ModelCheckDialogController: public Ui_ModelCheckDialogController {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MODELCHECKDIALOGVIEW_H
