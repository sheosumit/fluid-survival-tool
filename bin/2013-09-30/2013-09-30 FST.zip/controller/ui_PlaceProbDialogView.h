/********************************************************************************
** Form generated from reading UI file 'PlaceProbDialogView.ui'
**
** Created: Fri Jul 26 14:25:46 2013
**      by: Qt User Interface Compiler version 4.8.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PLACEPROBDIALOGVIEW_H
#define UI_PLACEPROBDIALOGVIEW_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QFormLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QRadioButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PlaceProbDialogController
{
public:
    QDialogButtonBox *buttonBox;
    QWidget *formLayoutWidget;
    QFormLayout *formLayout;
    QLabel *labelModelFile;
    QLabel *labelPathToFile;
    QLabel *labelPlaceName;
    QLineEdit *lineEditPlaceName;
    QLabel *labelMaxTime;
    QLineEdit *lineEditMaxTime;
    QLabel *labelTimeStep;
    QLineEdit *lineEditTimeStep;
    QRadioButton *radioConstRange;
    QLabel *label3dPlot;
    QRadioButton *radioSpecConst;
    QLabel *label2dPlot;
    QLabel *labelConst;
    QLineEdit *lineEditConst;
    QLabel *labelConstStep;
    QLineEdit *lineEditConstStep;
    QLabel *labelConstStart;
    QLineEdit *lineEditConstStart;
    QLabel *labelConstEnd;
    QLineEdit *lineEditConstEnd;

    void setupUi(QDialog *PlaceProbDialogController)
    {
        if (PlaceProbDialogController->objectName().isEmpty())
            PlaceProbDialogController->setObjectName(QString::fromUtf8("PlaceProbDialogController"));
        PlaceProbDialogController->resize(400, 412);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/resources/resources/introduction1.png"), QSize(), QIcon::Normal, QIcon::Off);
        PlaceProbDialogController->setWindowIcon(icon);
        PlaceProbDialogController->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        buttonBox = new QDialogButtonBox(PlaceProbDialogController);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(30, 370, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        formLayoutWidget = new QWidget(PlaceProbDialogController);
        formLayoutWidget->setObjectName(QString::fromUtf8("formLayoutWidget"));
        formLayoutWidget->setGeometry(QRect(10, 10, 381, 361));
        formLayout = new QFormLayout(formLayoutWidget);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        formLayout->setContentsMargins(0, 0, 0, 0);
        labelModelFile = new QLabel(formLayoutWidget);
        labelModelFile->setObjectName(QString::fromUtf8("labelModelFile"));

        formLayout->setWidget(1, QFormLayout::LabelRole, labelModelFile);

        labelPathToFile = new QLabel(formLayoutWidget);
        labelPathToFile->setObjectName(QString::fromUtf8("labelPathToFile"));

        formLayout->setWidget(1, QFormLayout::FieldRole, labelPathToFile);

        labelPlaceName = new QLabel(formLayoutWidget);
        labelPlaceName->setObjectName(QString::fromUtf8("labelPlaceName"));

        formLayout->setWidget(2, QFormLayout::LabelRole, labelPlaceName);

        lineEditPlaceName = new QLineEdit(formLayoutWidget);
        lineEditPlaceName->setObjectName(QString::fromUtf8("lineEditPlaceName"));

        formLayout->setWidget(2, QFormLayout::FieldRole, lineEditPlaceName);

        labelMaxTime = new QLabel(formLayoutWidget);
        labelMaxTime->setObjectName(QString::fromUtf8("labelMaxTime"));

        formLayout->setWidget(3, QFormLayout::LabelRole, labelMaxTime);

        lineEditMaxTime = new QLineEdit(formLayoutWidget);
        lineEditMaxTime->setObjectName(QString::fromUtf8("lineEditMaxTime"));

        formLayout->setWidget(3, QFormLayout::FieldRole, lineEditMaxTime);

        labelTimeStep = new QLabel(formLayoutWidget);
        labelTimeStep->setObjectName(QString::fromUtf8("labelTimeStep"));

        formLayout->setWidget(4, QFormLayout::LabelRole, labelTimeStep);

        lineEditTimeStep = new QLineEdit(formLayoutWidget);
        lineEditTimeStep->setObjectName(QString::fromUtf8("lineEditTimeStep"));

        formLayout->setWidget(4, QFormLayout::FieldRole, lineEditTimeStep);

        radioConstRange = new QRadioButton(formLayoutWidget);
        radioConstRange->setObjectName(QString::fromUtf8("radioConstRange"));
        radioConstRange->setChecked(true);

        formLayout->setWidget(7, QFormLayout::LabelRole, radioConstRange);

        label3dPlot = new QLabel(formLayoutWidget);
        label3dPlot->setObjectName(QString::fromUtf8("label3dPlot"));

        formLayout->setWidget(7, QFormLayout::FieldRole, label3dPlot);

        radioSpecConst = new QRadioButton(formLayoutWidget);
        radioSpecConst->setObjectName(QString::fromUtf8("radioSpecConst"));

        formLayout->setWidget(12, QFormLayout::LabelRole, radioSpecConst);

        label2dPlot = new QLabel(formLayoutWidget);
        label2dPlot->setObjectName(QString::fromUtf8("label2dPlot"));

        formLayout->setWidget(12, QFormLayout::FieldRole, label2dPlot);

        labelConst = new QLabel(formLayoutWidget);
        labelConst->setObjectName(QString::fromUtf8("labelConst"));
        labelConst->setEnabled(true);

        formLayout->setWidget(13, QFormLayout::LabelRole, labelConst);

        lineEditConst = new QLineEdit(formLayoutWidget);
        lineEditConst->setObjectName(QString::fromUtf8("lineEditConst"));
        lineEditConst->setEnabled(true);

        formLayout->setWidget(13, QFormLayout::FieldRole, lineEditConst);

        labelConstStep = new QLabel(formLayoutWidget);
        labelConstStep->setObjectName(QString::fromUtf8("labelConstStep"));

        formLayout->setWidget(8, QFormLayout::LabelRole, labelConstStep);

        lineEditConstStep = new QLineEdit(formLayoutWidget);
        lineEditConstStep->setObjectName(QString::fromUtf8("lineEditConstStep"));

        formLayout->setWidget(8, QFormLayout::FieldRole, lineEditConstStep);

        labelConstStart = new QLabel(formLayoutWidget);
        labelConstStart->setObjectName(QString::fromUtf8("labelConstStart"));
        labelConstStart->setEnabled(true);

        formLayout->setWidget(9, QFormLayout::LabelRole, labelConstStart);

        lineEditConstStart = new QLineEdit(formLayoutWidget);
        lineEditConstStart->setObjectName(QString::fromUtf8("lineEditConstStart"));
        lineEditConstStart->setEnabled(true);

        formLayout->setWidget(9, QFormLayout::FieldRole, lineEditConstStart);

        labelConstEnd = new QLabel(formLayoutWidget);
        labelConstEnd->setObjectName(QString::fromUtf8("labelConstEnd"));
        labelConstEnd->setEnabled(true);

        formLayout->setWidget(10, QFormLayout::LabelRole, labelConstEnd);

        lineEditConstEnd = new QLineEdit(formLayoutWidget);
        lineEditConstEnd->setObjectName(QString::fromUtf8("lineEditConstEnd"));
        lineEditConstEnd->setEnabled(true);

        formLayout->setWidget(10, QFormLayout::FieldRole, lineEditConstEnd);

        QWidget::setTabOrder(lineEditPlaceName, lineEditMaxTime);
        QWidget::setTabOrder(lineEditMaxTime, lineEditTimeStep);
        QWidget::setTabOrder(lineEditTimeStep, radioConstRange);
        QWidget::setTabOrder(radioConstRange, radioSpecConst);
        QWidget::setTabOrder(radioSpecConst, lineEditConst);
        QWidget::setTabOrder(lineEditConst, buttonBox);

        retranslateUi(PlaceProbDialogController);
        QObject::connect(buttonBox, SIGNAL(accepted()), PlaceProbDialogController, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), PlaceProbDialogController, SLOT(reject()));
        QObject::connect(lineEditConst, SIGNAL(textEdited(QString)), radioSpecConst, SLOT(click()));
        QObject::connect(lineEditConstStart, SIGNAL(textEdited(QString)), radioConstRange, SLOT(click()));
        QObject::connect(lineEditConstEnd, SIGNAL(textEdited(QString)), radioConstRange, SLOT(click()));

        QMetaObject::connectSlotsByName(PlaceProbDialogController);
    } // setupUi

    void retranslateUi(QDialog *PlaceProbDialogController)
    {
        PlaceProbDialogController->setWindowTitle(QApplication::translate("PlaceProbDialogController", "STD Configurations", 0, QApplication::UnicodeUTF8));
        labelModelFile->setText(QApplication::translate("PlaceProbDialogController", "Model File", 0, QApplication::UnicodeUTF8));
        labelPathToFile->setText(QApplication::translate("PlaceProbDialogController", "path_to_and_name_of_file", 0, QApplication::UnicodeUTF8));
        labelPlaceName->setText(QApplication::translate("PlaceProbDialogController", "Place name", 0, QApplication::UnicodeUTF8));
        lineEditPlaceName->setText(QApplication::translate("PlaceProbDialogController", "reservoir", 0, QApplication::UnicodeUTF8));
        labelMaxTime->setText(QApplication::translate("PlaceProbDialogController", "Maximum Time", 0, QApplication::UnicodeUTF8));
        lineEditMaxTime->setText(QApplication::translate("PlaceProbDialogController", "100", 0, QApplication::UnicodeUTF8));
        labelTimeStep->setText(QApplication::translate("PlaceProbDialogController", "Time step size", 0, QApplication::UnicodeUTF8));
        lineEditTimeStep->setText(QApplication::translate("PlaceProbDialogController", "1", 0, QApplication::UnicodeUTF8));
        radioConstRange->setText(QApplication::translate("PlaceProbDialogController", "Constant Range", 0, QApplication::UnicodeUTF8));
        label3dPlot->setText(QApplication::translate("PlaceProbDialogController", "output: 3-D plot + file", 0, QApplication::UnicodeUTF8));
        radioSpecConst->setText(QApplication::translate("PlaceProbDialogController", "Specific Constant", 0, QApplication::UnicodeUTF8));
        label2dPlot->setText(QApplication::translate("PlaceProbDialogController", "output: 2-D plot + file", 0, QApplication::UnicodeUTF8));
        labelConst->setText(QApplication::translate("PlaceProbDialogController", "Constant", 0, QApplication::UnicodeUTF8));
        lineEditConst->setText(QApplication::translate("PlaceProbDialogController", "5", 0, QApplication::UnicodeUTF8));
        labelConstStep->setText(QApplication::translate("PlaceProbDialogController", "Constant step size", 0, QApplication::UnicodeUTF8));
        lineEditConstStep->setText(QApplication::translate("PlaceProbDialogController", "0.2", 0, QApplication::UnicodeUTF8));
        labelConstStart->setText(QApplication::translate("PlaceProbDialogController", "Constant start", 0, QApplication::UnicodeUTF8));
        lineEditConstStart->setText(QApplication::translate("PlaceProbDialogController", "0", 0, QApplication::UnicodeUTF8));
        labelConstEnd->setText(QApplication::translate("PlaceProbDialogController", "Constant end", 0, QApplication::UnicodeUTF8));
        lineEditConstEnd->setText(QApplication::translate("PlaceProbDialogController", "8", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class PlaceProbDialogController: public Ui_PlaceProbDialogController {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PLACEPROBDIALOGVIEW_H
