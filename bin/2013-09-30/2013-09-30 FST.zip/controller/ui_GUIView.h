/********************************************************************************
** Form generated from reading UI file 'GUIView.ui'
**
** Created: Fri Jul 26 14:25:46 2013
**      by: Qt User Interface Compiler version 4.8.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GUIVIEW_H
#define UI_GUIVIEW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QGridLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QStatusBar>
#include <QtGui/QTextEdit>
#include <QtGui/QToolBar>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_GUIController
{
public:
    QAction *actionExit;
    QAction *newModel;
    QAction *openModel;
    QAction *actionRun;
    QAction *actionInfo;
    QAction *actionProject_website;
    QAction *saveModel;
    QAction *saveAsModel;
    QAction *actionTest;
    QAction *actionReservoir;
    QAction *actionDiscrete_Place;
    QAction *actionFluid_Place;
    QAction *actionDeterministic_Transition;
    QAction *actionImmediate_Transition;
    QAction *actionFluid_Transition;
    QAction *actionGeneral_Transition;
    QAction *actionDiscrete_Arc;
    QAction *actionFluid_Arc;
    QAction *actionInhibitor_Arc;
    QAction *actionTest_Arc;
    QAction *actionSTD;
    QAction *actionProbability_Distribution;
    QAction *actionModel_Checker;
    QAction *actionFormula_Prob_Plots;
    QAction *actionWater_cleaning_facility;
    QAction *actionSewage_water_cleaning;
    QAction *actionOverflow;
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QTextEdit *modelEditor;
    QLabel *modelFileName;
    QTextEdit *outputEditor;
    QMenuBar *menuBar;
    QMenu *menuHelp;
    QMenu *menuFile;
    QMenu *menuNew;
    QMenu *menuOpen;
    QMenu *menu_Save;
    QMenu *menuSave_As;
    QMenu *menuExamples;
    QMenu *menuTools;
    QMenu *menuGenerate;
    QStatusBar *statusBar;
    QToolBar *toolBar;

    void setupUi(QMainWindow *GUIController)
    {
        if (GUIController->objectName().isEmpty())
            GUIController->setObjectName(QString::fromUtf8("GUIController"));
        GUIController->setWindowModality(Qt::WindowModal);
        GUIController->setEnabled(true);
        GUIController->resize(892, 558);
        QFont font;
        font.setFamily(QString::fromUtf8("Ubuntu Mono"));
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(50);
        GUIController->setFont(font);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/resources/resources/logo.png"), QSize(), QIcon::Normal, QIcon::Off);
        GUIController->setWindowIcon(icon);
        GUIController->setAutoFillBackground(false);
        GUIController->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border-top-color: rgb(217, 217, 217);\n"
"selection-color: rgb(161, 161, 161);\n"
"border-color: rgb(231, 231, 231);"));
        GUIController->setDockOptions(QMainWindow::AllowTabbedDocks|QMainWindow::AnimatedDocks);
        GUIController->setUnifiedTitleAndToolBarOnMac(true);
        actionExit = new QAction(GUIController);
        actionExit->setObjectName(QString::fromUtf8("actionExit"));
        newModel = new QAction(GUIController);
        newModel->setObjectName(QString::fromUtf8("newModel"));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Ubuntu Mono"));
        font1.setPointSize(12);
        newModel->setFont(font1);
        openModel = new QAction(GUIController);
        openModel->setObjectName(QString::fromUtf8("openModel"));
        openModel->setFont(font1);
        actionRun = new QAction(GUIController);
        actionRun->setObjectName(QString::fromUtf8("actionRun"));
        actionInfo = new QAction(GUIController);
        actionInfo->setObjectName(QString::fromUtf8("actionInfo"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/resources/resources/dacs_logo.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        actionInfo->setIcon(icon1);
        actionInfo->setFont(font1);
        actionInfo->setIconVisibleInMenu(true);
        actionProject_website = new QAction(GUIController);
        actionProject_website->setObjectName(QString::fromUtf8("actionProject_website"));
        saveModel = new QAction(GUIController);
        saveModel->setObjectName(QString::fromUtf8("saveModel"));
        saveModel->setFont(font1);
        saveAsModel = new QAction(GUIController);
        saveAsModel->setObjectName(QString::fromUtf8("saveAsModel"));
        saveAsModel->setFont(font1);
        actionTest = new QAction(GUIController);
        actionTest->setObjectName(QString::fromUtf8("actionTest"));
        actionReservoir = new QAction(GUIController);
        actionReservoir->setObjectName(QString::fromUtf8("actionReservoir"));
        actionReservoir->setFont(font1);
        actionDiscrete_Place = new QAction(GUIController);
        actionDiscrete_Place->setObjectName(QString::fromUtf8("actionDiscrete_Place"));
        actionFluid_Place = new QAction(GUIController);
        actionFluid_Place->setObjectName(QString::fromUtf8("actionFluid_Place"));
        actionDeterministic_Transition = new QAction(GUIController);
        actionDeterministic_Transition->setObjectName(QString::fromUtf8("actionDeterministic_Transition"));
        actionImmediate_Transition = new QAction(GUIController);
        actionImmediate_Transition->setObjectName(QString::fromUtf8("actionImmediate_Transition"));
        actionFluid_Transition = new QAction(GUIController);
        actionFluid_Transition->setObjectName(QString::fromUtf8("actionFluid_Transition"));
        actionGeneral_Transition = new QAction(GUIController);
        actionGeneral_Transition->setObjectName(QString::fromUtf8("actionGeneral_Transition"));
        actionDiscrete_Arc = new QAction(GUIController);
        actionDiscrete_Arc->setObjectName(QString::fromUtf8("actionDiscrete_Arc"));
        actionFluid_Arc = new QAction(GUIController);
        actionFluid_Arc->setObjectName(QString::fromUtf8("actionFluid_Arc"));
        actionInhibitor_Arc = new QAction(GUIController);
        actionInhibitor_Arc->setObjectName(QString::fromUtf8("actionInhibitor_Arc"));
        actionTest_Arc = new QAction(GUIController);
        actionTest_Arc->setObjectName(QString::fromUtf8("actionTest_Arc"));
        actionSTD = new QAction(GUIController);
        actionSTD->setObjectName(QString::fromUtf8("actionSTD"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/resources/resources/introduction1.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSTD->setIcon(icon2);
        QFont font2;
        actionSTD->setFont(font2);
        actionSTD->setIconVisibleInMenu(true);
        actionProbability_Distribution = new QAction(GUIController);
        actionProbability_Distribution->setObjectName(QString::fromUtf8("actionProbability_Distribution"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/resources/resources/introduction3.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionProbability_Distribution->setIcon(icon3);
        actionProbability_Distribution->setFont(font2);
        actionProbability_Distribution->setIconVisibleInMenu(true);
        actionModel_Checker = new QAction(GUIController);
        actionModel_Checker->setObjectName(QString::fromUtf8("actionModel_Checker"));
        actionModel_Checker->setEnabled(true);
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/resources/resources/introduction4.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionModel_Checker->setIcon(icon4);
        actionModel_Checker->setIconVisibleInMenu(true);
        actionFormula_Prob_Plots = new QAction(GUIController);
        actionFormula_Prob_Plots->setObjectName(QString::fromUtf8("actionFormula_Prob_Plots"));
        actionFormula_Prob_Plots->setEnabled(false);
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/resources/resources/introduction2.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionFormula_Prob_Plots->setIcon(icon5);
        actionFormula_Prob_Plots->setIconVisibleInMenu(true);
        actionWater_cleaning_facility = new QAction(GUIController);
        actionWater_cleaning_facility->setObjectName(QString::fromUtf8("actionWater_cleaning_facility"));
        actionSewage_water_cleaning = new QAction(GUIController);
        actionSewage_water_cleaning->setObjectName(QString::fromUtf8("actionSewage_water_cleaning"));
        actionOverflow = new QAction(GUIController);
        actionOverflow->setObjectName(QString::fromUtf8("actionOverflow"));
        centralWidget = new QWidget(GUIController);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        modelEditor = new QTextEdit(centralWidget);
        modelEditor->setObjectName(QString::fromUtf8("modelEditor"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(1);
        sizePolicy.setHeightForWidth(modelEditor->sizePolicy().hasHeightForWidth());
        modelEditor->setSizePolicy(sizePolicy);
        QFont font3;
        font3.setFamily(QString::fromUtf8("Ubuntu"));
        font3.setPointSize(10);
        font3.setBold(false);
        font3.setItalic(false);
        font3.setWeight(50);
        modelEditor->setFont(font3);
        modelEditor->setFrameShape(QFrame::WinPanel);
        modelEditor->setFrameShadow(QFrame::Sunken);
        modelEditor->setLineWidth(1);

        gridLayout->addWidget(modelEditor, 1, 0, 1, 1);

        modelFileName = new QLabel(centralWidget);
        modelFileName->setObjectName(QString::fromUtf8("modelFileName"));
        modelFileName->setLayoutDirection(Qt::LeftToRight);

        gridLayout->addWidget(modelFileName, 0, 0, 1, 1);

        outputEditor = new QTextEdit(centralWidget);
        outputEditor->setObjectName(QString::fromUtf8("outputEditor"));
        outputEditor->setReadOnly(true);

        gridLayout->addWidget(outputEditor, 2, 0, 1, 1);

        GUIController->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(GUIController);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 892, 23));
        QPalette palette;
        QBrush brush(QColor(255, 255, 255, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush);
        palette.setBrush(QPalette::Active, QPalette::Window, brush);
        QBrush brush1(QColor(161, 161, 161, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::HighlightedText, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush);
        palette.setBrush(QPalette::Inactive, QPalette::HighlightedText, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush);
        palette.setBrush(QPalette::Disabled, QPalette::HighlightedText, brush1);
        menuBar->setPalette(palette);
        QFont font4;
        font4.setFamily(QString::fromUtf8("Ubuntu Mono"));
        font4.setPointSize(12);
        font4.setBold(true);
        font4.setWeight(75);
        menuBar->setFont(font4);
        menuBar->setLayoutDirection(Qt::LeftToRight);
        menuBar->setAutoFillBackground(false);
        menuBar->setStyleSheet(QString::fromUtf8("QMenuBar::item { background: rgb(255, 255, 255); }"));
        menuHelp = new QMenu(menuBar);
        menuHelp->setObjectName(QString::fromUtf8("menuHelp"));
        menuHelp->setFont(font1);
        menuFile = new QMenu(menuBar);
        menuFile->setObjectName(QString::fromUtf8("menuFile"));
        QPalette palette1;
        palette1.setBrush(QPalette::Active, QPalette::Button, brush);
        palette1.setBrush(QPalette::Active, QPalette::Base, brush);
        palette1.setBrush(QPalette::Active, QPalette::Window, brush);
        palette1.setBrush(QPalette::Active, QPalette::HighlightedText, brush1);
        palette1.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::Window, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::HighlightedText, brush1);
        palette1.setBrush(QPalette::Disabled, QPalette::Button, brush);
        palette1.setBrush(QPalette::Disabled, QPalette::Base, brush);
        palette1.setBrush(QPalette::Disabled, QPalette::Window, brush);
        palette1.setBrush(QPalette::Disabled, QPalette::HighlightedText, brush1);
        menuFile->setPalette(palette1);
        QFont font5;
        font5.setFamily(QString::fromUtf8("Ubuntu Mono"));
        font5.setPointSize(12);
        font5.setBold(false);
        font5.setWeight(50);
        menuFile->setFont(font5);
        menuFile->setStyleSheet(QString::fromUtf8(""));
        menuFile->setTearOffEnabled(false);
        menuFile->setSeparatorsCollapsible(false);
        menuNew = new QMenu(menuFile);
        menuNew->setObjectName(QString::fromUtf8("menuNew"));
        menuNew->setFont(font1);
        menuOpen = new QMenu(menuFile);
        menuOpen->setObjectName(QString::fromUtf8("menuOpen"));
        menuOpen->setFont(font1);
        menu_Save = new QMenu(menuFile);
        menu_Save->setObjectName(QString::fromUtf8("menu_Save"));
        QFont font6;
        font6.setFamily(QString::fromUtf8("Ubuntu Mono"));
        menu_Save->setFont(font6);
        menuSave_As = new QMenu(menuFile);
        menuSave_As->setObjectName(QString::fromUtf8("menuSave_As"));
        menuSave_As->setFont(font6);
        menuExamples = new QMenu(menuFile);
        menuExamples->setObjectName(QString::fromUtf8("menuExamples"));
        menuTools = new QMenu(menuBar);
        menuTools->setObjectName(QString::fromUtf8("menuTools"));
        menuTools->setFont(font1);
        menuGenerate = new QMenu(menuTools);
        menuGenerate->setObjectName(QString::fromUtf8("menuGenerate"));
        GUIController->setMenuBar(menuBar);
        statusBar = new QStatusBar(GUIController);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        GUIController->setStatusBar(statusBar);
        toolBar = new QToolBar(GUIController);
        toolBar->setObjectName(QString::fromUtf8("toolBar"));
        toolBar->setLayoutDirection(Qt::LeftToRight);
        toolBar->setAutoFillBackground(false);
        toolBar->setMovable(false);
        toolBar->setAllowedAreas(Qt::TopToolBarArea);
        toolBar->setIconSize(QSize(42, 42));
        toolBar->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        toolBar->setFloatable(false);
        GUIController->addToolBar(Qt::TopToolBarArea, toolBar);

        menuBar->addAction(menuFile->menuAction());
        menuBar->addAction(menuTools->menuAction());
        menuBar->addAction(menuHelp->menuAction());
        menuHelp->addAction(actionInfo);
        menuHelp->addAction(actionProject_website);
        menuFile->addAction(menuNew->menuAction());
        menuFile->addAction(menuOpen->menuAction());
        menuFile->addAction(menuExamples->menuAction());
        menuFile->addSeparator();
        menuFile->addAction(menu_Save->menuAction());
        menuFile->addAction(menuSave_As->menuAction());
        menuFile->addSeparator();
        menuFile->addAction(actionExit);
        menuNew->addAction(newModel);
        menuOpen->addAction(openModel);
        menu_Save->addAction(saveModel);
        menuSave_As->addAction(saveAsModel);
        menuExamples->addAction(actionReservoir);
        menuExamples->addAction(actionWater_cleaning_facility);
        menuExamples->addAction(actionSewage_water_cleaning);
        menuExamples->addAction(actionOverflow);
        menuTools->addAction(menuGenerate->menuAction());
        menuTools->addAction(actionModel_Checker);
        menuGenerate->addAction(actionSTD);
        menuGenerate->addAction(actionProbability_Distribution);
        toolBar->addAction(actionSTD);
        toolBar->addAction(actionProbability_Distribution);
        toolBar->addAction(actionModel_Checker);

        retranslateUi(GUIController);
        QObject::connect(openModel, SIGNAL(triggered()), GUIController, SLOT(modelOpen()));
        QObject::connect(newModel, SIGNAL(triggered()), GUIController, SLOT(modelNew()));
        QObject::connect(actionExit, SIGNAL(triggered()), GUIController, SLOT(close()));
        QObject::connect(actionInfo, SIGNAL(triggered()), GUIController, SLOT(about()));
        QObject::connect(saveModel, SIGNAL(triggered()), GUIController, SLOT(modelSave()));
        QObject::connect(saveAsModel, SIGNAL(triggered()), GUIController, SLOT(modelSaveAs()));
        QObject::connect(actionProject_website, SIGNAL(triggered()), GUIController, SLOT(openProjectWebsite()));
        QObject::connect(modelEditor, SIGNAL(textChanged()), GUIController, SLOT(modelModified()));
        QObject::connect(actionSTD, SIGNAL(triggered()), GUIController, SLOT(generateSTD()));
        QObject::connect(actionProbability_Distribution, SIGNAL(triggered()), GUIController, SLOT(generateProbFunc()));
        QObject::connect(actionModel_Checker, SIGNAL(triggered()), GUIController, SLOT(modelCheck()));
        QObject::connect(actionReservoir, SIGNAL(triggered()), GUIController, SLOT(exampleReservoir()));
        QObject::connect(actionWater_cleaning_facility, SIGNAL(triggered()), GUIController, SLOT(exampleWater()));
        QObject::connect(actionSewage_water_cleaning, SIGNAL(triggered()), GUIController, SLOT(exampleSewage()));
        QObject::connect(actionOverflow, SIGNAL(triggered()), GUIController, SLOT(exampleOverflow()));

        QMetaObject::connectSlotsByName(GUIController);
    } // setupUi

    void retranslateUi(QMainWindow *GUIController)
    {
        GUIController->setWindowTitle(QApplication::translate("GUIController", "FST", 0, QApplication::UnicodeUTF8));
        actionExit->setText(QApplication::translate("GUIController", "E&xit", 0, QApplication::UnicodeUTF8));
        newModel->setText(QApplication::translate("GUIController", "&HPnG Model", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_STATUSTIP
        newModel->setStatusTip(QApplication::translate("GUIController", "Create a new HPnG model file in the editor", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_STATUSTIP
        newModel->setShortcut(QApplication::translate("GUIController", "Ctrl+N", 0, QApplication::UnicodeUTF8));
        openModel->setText(QApplication::translate("GUIController", "&HPnG Model", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_STATUSTIP
        openModel->setStatusTip(QApplication::translate("GUIController", "Open a HPnG model file in the editor", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_STATUSTIP
        openModel->setShortcut(QApplication::translate("GUIController", "Ctrl+O", 0, QApplication::UnicodeUTF8));
        actionRun->setText(QApplication::translate("GUIController", "Run...", 0, QApplication::UnicodeUTF8));
        actionInfo->setText(QApplication::translate("GUIController", "&About", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_STATUSTIP
        actionInfo->setStatusTip(QApplication::translate("GUIController", "Show information the tool", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_STATUSTIP
        actionProject_website->setText(QApplication::translate("GUIController", "&Project Website", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_STATUSTIP
        actionProject_website->setStatusTip(QApplication::translate("GUIController", "Go to the project website", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_STATUSTIP
        saveModel->setText(QApplication::translate("GUIController", "&HPnG Model", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_STATUSTIP
        saveModel->setStatusTip(QApplication::translate("GUIController", "Save the HPnG model file", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_STATUSTIP
        saveModel->setShortcut(QApplication::translate("GUIController", "Ctrl+S", 0, QApplication::UnicodeUTF8));
        saveAsModel->setText(QApplication::translate("GUIController", "&HPnG Model", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_STATUSTIP
        saveAsModel->setStatusTip(QApplication::translate("GUIController", "Save a HPnG model file in a specific location", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_STATUSTIP
        actionTest->setText(QApplication::translate("GUIController", "Test", 0, QApplication::UnicodeUTF8));
        actionReservoir->setText(QApplication::translate("GUIController", "Reservoir", 0, QApplication::UnicodeUTF8));
        actionDiscrete_Place->setText(QApplication::translate("GUIController", "Discrete Place", 0, QApplication::UnicodeUTF8));
        actionFluid_Place->setText(QApplication::translate("GUIController", "Fluid Place", 0, QApplication::UnicodeUTF8));
        actionDeterministic_Transition->setText(QApplication::translate("GUIController", "Deterministic Transition", 0, QApplication::UnicodeUTF8));
        actionImmediate_Transition->setText(QApplication::translate("GUIController", "Immediate Transition", 0, QApplication::UnicodeUTF8));
        actionFluid_Transition->setText(QApplication::translate("GUIController", "Fluid Transition", 0, QApplication::UnicodeUTF8));
        actionGeneral_Transition->setText(QApplication::translate("GUIController", "General Transition", 0, QApplication::UnicodeUTF8));
        actionDiscrete_Arc->setText(QApplication::translate("GUIController", "Discrete Arc", 0, QApplication::UnicodeUTF8));
        actionFluid_Arc->setText(QApplication::translate("GUIController", "Fluid Arc", 0, QApplication::UnicodeUTF8));
        actionInhibitor_Arc->setText(QApplication::translate("GUIController", "Inhibitor Arc", 0, QApplication::UnicodeUTF8));
        actionTest_Arc->setText(QApplication::translate("GUIController", "Test Arc", 0, QApplication::UnicodeUTF8));
        actionSTD->setText(QApplication::translate("GUIController", "&STD...", 0, QApplication::UnicodeUTF8));
        actionProbability_Distribution->setText(QApplication::translate("GUIController", "&Cont. Place Prob. Plots...", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        actionProbability_Distribution->setToolTip(QApplication::translate("GUIController", "Cont. Prob. Plots...", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        actionModel_Checker->setText(QApplication::translate("GUIController", "&Model Checker...", 0, QApplication::UnicodeUTF8));
        actionFormula_Prob_Plots->setText(QApplication::translate("GUIController", "&Formula Prob. Plots...", 0, QApplication::UnicodeUTF8));
        actionWater_cleaning_facility->setText(QApplication::translate("GUIController", "Water cleaning facility", 0, QApplication::UnicodeUTF8));
        actionSewage_water_cleaning->setText(QApplication::translate("GUIController", "Sewage water cleaning", 0, QApplication::UnicodeUTF8));
        actionOverflow->setText(QApplication::translate("GUIController", "Overflow", 0, QApplication::UnicodeUTF8));
        modelEditor->setHtml(QApplication::translate("GUIController", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">#####################</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">#    Demo HPNG Model File     #</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">#####################</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">#</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-inden"
                        "t:0; text-indent:0px;\">#### Number of places</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">11</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"># List of places</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"># Syntax: type id discMarking fluidLevel fluidBound</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">#</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"># Types:</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">#</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-inden"
                        "t:0px;\"># DISCRETE   0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"># FLUID      1</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">#</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">0 Input1On   1 0 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">0 Filt1On  1 0 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">0 Stor1On  1 0 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">0 Off      0 0 0 </p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">0 time21to"
                        "6   1 0 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">0 time6to21   0 0 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">1 soft1      0 20 20</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">1 filt1      0 0 2</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">1 filt2      0 0 2</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">1 stor2      0 8 8</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">0 failonce   1 0 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0p"
                        "x;\">#</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">#### Number of transitions</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">10</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">#</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"># List of transitions</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"># Syntax: type id discFiringTime weight priority fluidFlowRate genFireRate(EXP)</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">#</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0"
                        "; text-indent:0px;\"># Types:</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">#</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"># DETERMINISTIC   0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"># IMMEDIATE       1</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"># FLUID           2</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"># GENERAL         3</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">#</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">2 input1"
                        "  0 0 0 2.0 na</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">2 pump1a  0 0 0 10.0 na</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">2 pump1b  0 0 0 10.0 na</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">2 pump1c  0 0 0 1.7 na</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">2 demand21to6  0 0 0 1.0 na</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">2 demand6to21  0 0 0 2.0 na</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">0 failure  3 1 0 0 na</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0p"
                        "x; -qt-block-indent:0; text-indent:0px;\">3 repair   1 1 0 0 exp{10}</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">0 at6  9 1 0 0 na</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">0 at21 15 1 0 0 na</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">#</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">#### Number of arcs</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">23</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">#</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-ind"
                        "ent:0px;\"># List of arcs</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"># Syntax: type id fromId toId weight share priority</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">#</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"># Types:</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"># DISCRETE_INPUT  0  from a place to a transition</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"># DISCRETE_OUTPUT 1  from a transition to a place</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"># FLUID_INPUT     2</p>\n"
"<p style=\" margin-top:0px; margin"
                        "-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"># FLUID_OUTPUT    3   from a transition to a fluid place</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"># INHIBITOR       4</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"># TEST            5   from place to transition</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">#</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"># Input,test,inhibitor: Place -&gt; Transition,  Output: Transition -&gt; Place</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">#</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:"
                        "0px; -qt-block-indent:0; text-indent:0px;\">3 pipe1a input1 soft1  1 1 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">2 pipe1b soft1  pump1a 1 1 0 </p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">3 pipe1c pump1a filt1  1 1 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">2 pipe1d filt1  pump1b 1 1 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">3 pipe1e pump1b filt2  1 1 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">2 pipe1f filt2  pump1c 1 1 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">3 pipe1g pump1c stor2  1 1 0</p>"
                        "\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">2 out21  stor2 demand21to6 1 1 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">2 out6   stor2 demand6to21 1 1 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">5 teIn1  Input1On input1 1 1 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">5 teFi1  Filt1On  pump1a 1 1 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">5 teSt1  Stor1On  pump1b 1 1 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">0 in6    time21to6   at6 1 1 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-le"
                        "ft:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">0 in21   time6to21 at21 1 1 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">1 out21b   at6 time6to21 1 1 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">1 out6b    at21  time21to6  1 1 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">5 test21to6 time21to6 demand21to6 1 1 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">5 test6to21 time6to21 demand6to21 1 1 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">0 inBreak  Input1On failure 1 1 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent"
                        ":0; text-indent:0px;\">1 outBreak failure Off 1 1 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">0 inRepair Off repair  1 1 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">1 outRepair repair Input1On 1 1 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">0 failoncetest failonce failure 1 1 0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">#</p></body></html>", 0, QApplication::UnicodeUTF8));
        modelFileName->setText(QApplication::translate("GUIController", "untitled.hpng", 0, QApplication::UnicodeUTF8));
        outputEditor->setHtml(QApplication::translate("GUIController", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">---- Application Output ----</p></body></html>", 0, QApplication::UnicodeUTF8));
        menuHelp->setTitle(QApplication::translate("GUIController", "&Help", 0, QApplication::UnicodeUTF8));
        menuFile->setTitle(QApplication::translate("GUIController", "&File", 0, QApplication::UnicodeUTF8));
        menuNew->setTitle(QApplication::translate("GUIController", "&New", 0, QApplication::UnicodeUTF8));
        menuOpen->setTitle(QApplication::translate("GUIController", "&Open", 0, QApplication::UnicodeUTF8));
        menu_Save->setTitle(QApplication::translate("GUIController", "&Save", 0, QApplication::UnicodeUTF8));
        menuSave_As->setTitle(QApplication::translate("GUIController", "Save &As", 0, QApplication::UnicodeUTF8));
        menuExamples->setTitle(QApplication::translate("GUIController", "Examples", 0, QApplication::UnicodeUTF8));
        menuTools->setTitle(QApplication::translate("GUIController", "&Tools", 0, QApplication::UnicodeUTF8));
        menuGenerate->setTitle(QApplication::translate("GUIController", "&Generate...", 0, QApplication::UnicodeUTF8));
        toolBar->setWindowTitle(QApplication::translate("GUIController", "toolBar", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class GUIController: public Ui_GUIController {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GUIVIEW_H
