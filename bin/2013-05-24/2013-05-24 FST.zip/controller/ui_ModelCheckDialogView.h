/********************************************************************************
** Form generated from reading UI file 'ModelCheckDialogView.ui'
**
** Created: Fri May 24 19:44:16 2013
**      by: Qt User Interface Compiler version 4.8.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MODELCHECKDIALOGVIEW_H
#define UI_MODELCHECKDIALOGVIEW_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QFormLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ModelCheckDialogController
{
public:
    QDialogButtonBox *buttonBox;
    QWidget *formLayoutWidget;
    QFormLayout *formLayout;
    QLabel *labelModelFile;
    QLabel *labelPathToFile;
    QLabel *labelFormula;
    QLineEdit *lineEditFormula;
    QComboBox *comboFormula;
    QLabel *labelTTC;
    QLineEdit *lineEditTTC;
    QLabel *labelMaxTime;
    QLineEdit *lineEditMaxTime;

    void setupUi(QDialog *ModelCheckDialogController)
    {
        if (ModelCheckDialogController->objectName().isEmpty())
            ModelCheckDialogController->setObjectName(QString::fromUtf8("ModelCheckDialogController"));
        ModelCheckDialogController->resize(400, 300);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/resources/resources/introduction1.png"), QSize(), QIcon::Normal, QIcon::Off);
        ModelCheckDialogController->setWindowIcon(icon);
        ModelCheckDialogController->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        buttonBox = new QDialogButtonBox(ModelCheckDialogController);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(30, 240, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        formLayoutWidget = new QWidget(ModelCheckDialogController);
        formLayoutWidget->setObjectName(QString::fromUtf8("formLayoutWidget"));
        formLayoutWidget->setGeometry(QRect(10, 10, 463, 221));
        formLayout = new QFormLayout(formLayoutWidget);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        formLayout->setContentsMargins(0, 0, 0, 0);
        labelModelFile = new QLabel(formLayoutWidget);
        labelModelFile->setObjectName(QString::fromUtf8("labelModelFile"));

        formLayout->setWidget(1, QFormLayout::LabelRole, labelModelFile);

        labelPathToFile = new QLabel(formLayoutWidget);
        labelPathToFile->setObjectName(QString::fromUtf8("labelPathToFile"));

        formLayout->setWidget(1, QFormLayout::FieldRole, labelPathToFile);

        labelFormula = new QLabel(formLayoutWidget);
        labelFormula->setObjectName(QString::fromUtf8("labelFormula"));
        labelFormula->setEnabled(true);

        formLayout->setWidget(2, QFormLayout::LabelRole, labelFormula);

        lineEditFormula = new QLineEdit(formLayoutWidget);
        lineEditFormula->setObjectName(QString::fromUtf8("lineEditFormula"));
        lineEditFormula->setEnabled(false);

        formLayout->setWidget(2, QFormLayout::FieldRole, lineEditFormula);

        comboFormula = new QComboBox(formLayoutWidget);
        comboFormula->setObjectName(QString::fromUtf8("comboFormula"));

        formLayout->setWidget(3, QFormLayout::FieldRole, comboFormula);

        labelTTC = new QLabel(formLayoutWidget);
        labelTTC->setObjectName(QString::fromUtf8("labelTTC"));
        labelTTC->setEnabled(true);

        formLayout->setWidget(4, QFormLayout::LabelRole, labelTTC);

        lineEditTTC = new QLineEdit(formLayoutWidget);
        lineEditTTC->setObjectName(QString::fromUtf8("lineEditTTC"));
        lineEditTTC->setEnabled(true);

        formLayout->setWidget(4, QFormLayout::FieldRole, lineEditTTC);

        labelMaxTime = new QLabel(formLayoutWidget);
        labelMaxTime->setObjectName(QString::fromUtf8("labelMaxTime"));
        labelMaxTime->setEnabled(true);

        formLayout->setWidget(5, QFormLayout::LabelRole, labelMaxTime);

        lineEditMaxTime = new QLineEdit(formLayoutWidget);
        lineEditMaxTime->setObjectName(QString::fromUtf8("lineEditMaxTime"));
        lineEditMaxTime->setEnabled(true);

        formLayout->setWidget(5, QFormLayout::FieldRole, lineEditMaxTime);

        QWidget::setTabOrder(lineEditFormula, comboFormula);
        QWidget::setTabOrder(comboFormula, lineEditTTC);
        QWidget::setTabOrder(lineEditTTC, lineEditMaxTime);
        QWidget::setTabOrder(lineEditMaxTime, buttonBox);

        retranslateUi(ModelCheckDialogController);
        QObject::connect(buttonBox, SIGNAL(accepted()), ModelCheckDialogController, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), ModelCheckDialogController, SLOT(reject()));

        QMetaObject::connectSlotsByName(ModelCheckDialogController);
    } // setupUi

    void retranslateUi(QDialog *ModelCheckDialogController)
    {
        ModelCheckDialogController->setWindowTitle(QApplication::translate("ModelCheckDialogController", "STD Configurations", 0, QApplication::UnicodeUTF8));
        labelModelFile->setText(QApplication::translate("ModelCheckDialogController", "Model File", 0, QApplication::UnicodeUTF8));
        labelPathToFile->setText(QApplication::translate("ModelCheckDialogController", "path_to_and_name_of_file", 0, QApplication::UnicodeUTF8));
        labelFormula->setText(QApplication::translate("ModelCheckDialogController", "Formula", 0, QApplication::UnicodeUTF8));
        comboFormula->clear();
        comboFormula->insertItems(0, QStringList()
         << QApplication::translate("ModelCheckDialogController", "Pr<=0.2 (P(1) == 1)", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ModelCheckDialogController", "Pr<=0.2 (P(6) <= 0.1)", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ModelCheckDialogController", "Pr<=0.2 (P(6) <= 0.2 AND P(6) <= 0.1)", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ModelCheckDialogController", "Pr<=0.2 ~(P(6) == 0.1)", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ModelCheckDialogController", "Pr<=0.2 ~(P(1) == 1)", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ModelCheckDialogController", "Pr<=0.2 (tt)", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ModelCheckDialogController", "Pr<=0.2 (P(1)=1 U[0,10] P(8)=0.1)", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("ModelCheckDialogController", "Pr<=0.2 ((P(1)=1 AND P(8)<=0.1) U[0,10] P(9)=0.2)", 0, QApplication::UnicodeUTF8)
        );
        labelTTC->setText(QApplication::translate("ModelCheckDialogController", "Time To Check", 0, QApplication::UnicodeUTF8));
        labelMaxTime->setText(QApplication::translate("ModelCheckDialogController", "Maximum Time", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class ModelCheckDialogController: public Ui_ModelCheckDialogController {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MODELCHECKDIALOGVIEW_H
