/********************************************************************************
** Form generated from reading UI file 'STDDialogView.ui'
**
** Created: Mon May 27 14:51:21 2013
**      by: Qt User Interface Compiler version 4.8.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STDDIALOGVIEW_H
#define UI_STDDIALOGVIEW_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QFormLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_STDDialogController
{
public:
    QDialogButtonBox *buttonBox;
    QWidget *formLayoutWidget;
    QFormLayout *formLayout;
    QLabel *labelMaxTime;
    QLineEdit *lineEditMaxTime;
    QLabel *labelModelFile;
    QLabel *labelPathToFile;
    QLabel *labelImageScale;
    QLineEdit *lineEditImageScale;

    void setupUi(QDialog *STDDialogController)
    {
        if (STDDialogController->objectName().isEmpty())
            STDDialogController->setObjectName(QString::fromUtf8("STDDialogController"));
        STDDialogController->resize(400, 300);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/resources/resources/introduction1.png"), QSize(), QIcon::Normal, QIcon::Off);
        STDDialogController->setWindowIcon(icon);
        STDDialogController->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        buttonBox = new QDialogButtonBox(STDDialogController);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(30, 240, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        formLayoutWidget = new QWidget(STDDialogController);
        formLayoutWidget->setObjectName(QString::fromUtf8("formLayoutWidget"));
        formLayoutWidget->setGeometry(QRect(10, 10, 381, 221));
        formLayout = new QFormLayout(formLayoutWidget);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        formLayout->setContentsMargins(0, 0, 0, 0);
        labelMaxTime = new QLabel(formLayoutWidget);
        labelMaxTime->setObjectName(QString::fromUtf8("labelMaxTime"));
        labelMaxTime->setEnabled(true);

        formLayout->setWidget(2, QFormLayout::LabelRole, labelMaxTime);

        lineEditMaxTime = new QLineEdit(formLayoutWidget);
        lineEditMaxTime->setObjectName(QString::fromUtf8("lineEditMaxTime"));
        lineEditMaxTime->setEnabled(true);

        formLayout->setWidget(2, QFormLayout::FieldRole, lineEditMaxTime);

        labelModelFile = new QLabel(formLayoutWidget);
        labelModelFile->setObjectName(QString::fromUtf8("labelModelFile"));

        formLayout->setWidget(1, QFormLayout::LabelRole, labelModelFile);

        labelPathToFile = new QLabel(formLayoutWidget);
        labelPathToFile->setObjectName(QString::fromUtf8("labelPathToFile"));

        formLayout->setWidget(1, QFormLayout::FieldRole, labelPathToFile);

        labelImageScale = new QLabel(formLayoutWidget);
        labelImageScale->setObjectName(QString::fromUtf8("labelImageScale"));
        labelImageScale->setEnabled(true);

        formLayout->setWidget(3, QFormLayout::LabelRole, labelImageScale);

        lineEditImageScale = new QLineEdit(formLayoutWidget);
        lineEditImageScale->setObjectName(QString::fromUtf8("lineEditImageScale"));
        lineEditImageScale->setEnabled(true);

        formLayout->setWidget(3, QFormLayout::FieldRole, lineEditImageScale);

        QWidget::setTabOrder(lineEditMaxTime, lineEditImageScale);
        QWidget::setTabOrder(lineEditImageScale, buttonBox);

        retranslateUi(STDDialogController);
        QObject::connect(buttonBox, SIGNAL(accepted()), STDDialogController, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), STDDialogController, SLOT(reject()));

        QMetaObject::connectSlotsByName(STDDialogController);
    } // setupUi

    void retranslateUi(QDialog *STDDialogController)
    {
        STDDialogController->setWindowTitle(QApplication::translate("STDDialogController", "STD Configurations", 0, QApplication::UnicodeUTF8));
        labelMaxTime->setText(QApplication::translate("STDDialogController", "Maximum Time", 0, QApplication::UnicodeUTF8));
        lineEditMaxTime->setText(QApplication::translate("STDDialogController", "100", 0, QApplication::UnicodeUTF8));
        labelModelFile->setText(QApplication::translate("STDDialogController", "Model File", 0, QApplication::UnicodeUTF8));
        labelPathToFile->setText(QApplication::translate("STDDialogController", "path_to_and_name_of_file", 0, QApplication::UnicodeUTF8));
        labelImageScale->setText(QApplication::translate("STDDialogController", "Image scale", 0, QApplication::UnicodeUTF8));
        lineEditImageScale->setText(QApplication::translate("STDDialogController", "7", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class STDDialogController: public Ui_STDDialogController {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STDDIALOGVIEW_H
